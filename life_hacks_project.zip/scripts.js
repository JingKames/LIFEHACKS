let cartCount = 0;
const cartCounter = document.getElementById('cart-count');
document.querySelectorAll('.product button').forEach(button => {
    button.addEventListener('click', () => {
        const productName = button.getAttribute('data-product');
        alert(`${productName} added to cart!`);
        cartCount++;
        cartCounter.textContent = cartCount;
    });
});
